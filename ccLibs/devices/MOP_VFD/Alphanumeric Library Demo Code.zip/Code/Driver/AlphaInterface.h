#ifndef ALPHAINTERFACE_H
#define ALPHAINTERFACE_H
#ifdef __GNUC__
#include <sys/types.h>
#endif
#include <stdint.h>
uint32_t CreateInterface(char port_name[]);
uint32_t DestroyInterface(void);
uint32_t SetInterfaceParameters(uint32_t baudRate);
uint32_t SetInterfaceTimeouts(uint32_t readIntervalTimeout);
uint32_t Write(uint8_t data[], size_t length);
uint32_t Read(uint8_t data[], size_t length);
#endif
