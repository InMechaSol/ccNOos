//Troy Clark, Matrix Orbital 2014
//www.matrixorbital.ca
//support@matrixorbital.ca

#include "AlphaDriver.h"
#include <string.h>

 void WriteString(char *data)
{
	 Write((uint8_t*)data, strlen(data));
}

void ChangeBaudRate(uint8_t speed)
{
	uint8_t command[] = { 254, 57, speed };
	Write(command, sizeof(command));
}

void ChangeI2CSlaveAddress(uint8_t address)
{
	uint8_t command[] = { 254, 51, address };
	Write(command, sizeof(command));
}

void TransmissionProtocolSelect(uint8_t protocol)
{
	uint8_t command[] = { 254, 160, protocol };
	Write(command, sizeof(command));
}

void SetaNonStandardBaudRate(uint16_t speed)
{
	uint8_t command[] = { 254, 164, SHORT_TO_BYTE(speed) };
	Write(command, sizeof(command));
}

uint32_t SoftwareReset(uint8_t data[], size_t length)
{
	uint8_t command[] = { 254, 253, 77, 79, 117, 110 };
	Write(command, sizeof(command));
	return (Read(data, length));
}

void ClearScreen(void)
{
	uint8_t command[] = { 254, 88 };
	Write(command, sizeof(command));
}

void ChangetheStartUpScreen(uint8_t characters[], size_t length)
{
	uint8_t command[] = { 254, 64 };
	Write(command, sizeof(command));
	Write(characters, length);
}

void AutoScrollOn(void)
{
	uint8_t command[] = { 254, 81 };
	Write(command, sizeof(command));
}

void AutoScrollOff(void)
{
	uint8_t command[] = { 254, 82 };
	Write(command, sizeof(command));
}

void SetAutoLineWrapOn(void)
{
	uint8_t command[] = { 254, 67 };
	Write(command, sizeof(command));
}

void SetAutoLineWrapOff(void)
{
	uint8_t command[] = { 254, 68 };
	Write(command, sizeof(command));
}

void SetCursorPosition(uint8_t row, uint8_t column)
{
	uint8_t command[] = { 254, 71, row, column };
	Write(command, sizeof(command));
}

void GoHome(void)
{
	uint8_t command[] = { 254, 72 };
	Write(command, sizeof(command));
}

void MoveCursorBack(void)
{
	uint8_t command[] = { 254, 76 };
	Write(command, sizeof(command));
}

void MoveCursorForward(void)
{
	uint8_t command[] = { 254, 77 };
	Write(command, sizeof(command));
}

void UnderlineCursorOn(void)
{
	uint8_t command[] = { 254, 74 };
	Write(command, sizeof(command));
}

void UnderlineCursorOff(void)
{
	uint8_t command[] = { 254, 75 };
	Write(command, sizeof(command));
}

void BlinkingBlockCursorOn(void)
{
	uint8_t command[] = { 254, 83 };
	Write(command, sizeof(command));
}

void BlinkingBlockCursorOff(void)
{
	uint8_t command[] = { 254, 84 };
	Write(command, sizeof(command));
}

void CreateaCustomCharacter(uint8_t id, uint8_t data[], size_t length)
{
	uint8_t command[] = { 254, 78, id };
	Write(command, sizeof(command));
	Write(data, length);
}

void SaveCustomCharacters(uint8_t bank, uint8_t id, uint8_t data[], size_t length)
{
	uint8_t command[] = { 254, 193, bank, id };
	Write(command, sizeof(command));
	Write(data, length);
}

void LoadCustomCharacters(uint8_t bank)
{
	uint8_t command[] = { 254, 192, bank };
	Write(command, sizeof(command));
}

void SaveStartUpScreenCustomCharacters(uint8_t id, uint8_t data[], size_t length)
{
	uint8_t command[] = { 254, 194, id };
	Write(command, sizeof(command));
	Write(data, length);
}

void InitializeMediumNumbers(void)
{
	uint8_t command[] = { 254, 109 };
	Write(command, sizeof(command));
}

void PlaceMediumNumbers(uint8_t row, uint8_t column, uint8_t digit)
{
	uint8_t command[] = { 254, 111, row, column, digit };
	Write(command, sizeof(command));
}

void InitializeLargeNumbers(void)
{
	uint8_t command[] = { 254, 110 };
	Write(command, sizeof(command));
}

void PlaceLargeNumbers(uint8_t column, uint8_t digit)
{
	uint8_t command[] = { 254, 35, column, digit };
	Write(command, sizeof(command));
}

void InitializeHorizontalBar(void)
{
	uint8_t command[] = { 254, 104 };
	Write(command, sizeof(command));
}

void PlaceHorizontalBarGraph(uint8_t column, uint8_t row, uint8_t direction, uint8_t length)
{
	uint8_t command[] = { 254, 124, column, row, direction, length };
	Write(command, sizeof(command));
}

void InitializeNarrowVerticalBar(void)
{
	uint8_t command[] = { 254, 115 };
	Write(command, sizeof(command));
}

void InitializeWideVerticalBar(void)
{
	uint8_t command[] = { 254, 118 };
	Write(command, sizeof(command));
}

void PlaceVerticalBar(uint8_t column, uint8_t length)
{
	uint8_t command[] = { 254, 61, column, length };
	Write(command, sizeof(command));
}

void GeneralPurposeOutputOn(uint8_t number)
{
	uint8_t command[] = { 254, 87, number };
	Write(command, sizeof(command));
}

void GeneralPurposeOutputOff(uint8_t number)
{
	uint8_t command[] = { 254, 86, number };
	Write(command, sizeof(command));
}

void SetStartUpGPOState(uint8_t number, uint8_t state)
{
	uint8_t command[] = { 254, 195, number, state };
	Write(command, sizeof(command));
}

void SetLEDIndicators(uint8_t number, uint8_t colour)
{
	uint8_t command[] = { 254, 90, number, colour };
	Write(command, sizeof(command));
}

uint32_t SearchforaOneWireDevice(uint8_t data[], size_t length)
{
	uint8_t command[] = { 254, 200, 2 };
	Write(command, sizeof(command));
	return (Read(data, length));
}

void DallasOneWireTransaction(uint8_t flags, uint8_t sendbits, uint8_t receivebits, uint8_t data[], size_t length)
{
	uint8_t command[] = { 254, 200, 1, flags, sendbits, receivebits };
	Write(command, sizeof(command));
	Write(data, length);
}

void ActivatePiezoBuzzer(uint8_t time)
{
	uint8_t command[] = { 254, 140, time };
	Write(command, sizeof(command));
}

void SetKeypadBuzzerBeep(uint8_t setting)
{
	uint8_t command[] = { 254, 182, setting };
	Write(command, sizeof(command));
}

void AutoTransmitKeyPressesOn(void)
{
	uint8_t command[] = { 254, 65 };
	Write(command, sizeof(command));
}

void AutoTransmitKeyPressesOff(void)
{
	uint8_t command[] = { 254, 79 };
	Write(command, sizeof(command));
}

uint32_t PollKeyPress(uint8_t data[], size_t length)
{
	uint8_t command[] = { 254, 38 };
	Write(command, sizeof(command));
	return (Read(data, length));
}

void ClearKeyBuffer(void)
{
	uint8_t command[] = { 254, 69 };
	Write(command, sizeof(command));
}

void SetDebounceTime(uint8_t time)
{
	uint8_t command[] = { 254, 85, time };
	Write(command, sizeof(command));
}

void SetAutoRepeatMode(uint8_t mode)
{
	uint8_t command[] = { 254, 126, mode };
	Write(command, sizeof(command));
}

void AutoRepeatModeOff(void)
{
	uint8_t command[] = { 254, 96 };
	Write(command, sizeof(command));
}

void AssignKeypadCodes(uint8_t keydown[], uint8_t keyup[], size_t length)
{
	uint8_t command[] = { 254, 213 };
	Write(command, sizeof(command));
	Write(keydown, length);
	Write(keyup, length);
}

void KeypadBacklightOff(void)
{
	uint8_t command[] = { 254, 155 };
	Write(command, sizeof(command));
}

void SetKeypadBrightness(uint8_t brightness)
{
	uint8_t command[] = { 254, 156, brightness };
	Write(command, sizeof(command));
}

void SetAutoBacklight(uint8_t setting)
{
	uint8_t command[] = { 254, 157, setting };
	Write(command, sizeof(command));
}

void BacklightOn(uint8_t minutes)
{
	uint8_t command[] = { 254, 66, minutes };
	Write(command, sizeof(command));
}

void BacklightOff(void)
{
	uint8_t command[] = { 254, 70 };
	Write(command, sizeof(command));
}

void SetBrightness(uint8_t brightness)
{
	uint8_t command[] = { 254, 153, brightness };
	Write(command, sizeof(command));
}

void SetandSaveBrightness(uint8_t brightness)
{
	uint8_t command[] = { 254, 152, brightness };
	Write(command, sizeof(command));
}

void SetBacklightColour(uint8_t red, uint8_t green, uint8_t blue)
{
	uint8_t command[] = { 254, 130, red, green, blue };
	Write(command, sizeof(command));
}

void SetContrast(uint8_t contrast)
{
	uint8_t command[] = { 254, 80, contrast };
	Write(command, sizeof(command));
}

void SetandSaveContrast(uint8_t contrast)
{
	uint8_t command[] = { 254, 145, contrast };
	Write(command, sizeof(command));
}

void SetVFDBrightness(uint8_t brightness)
{
	uint8_t command[] = { 254, 89, brightness };
	Write(command, sizeof(command));
}

void SetandSaveVFDBrightness(uint8_t brightness)
{
	uint8_t command[] = { 254, 145, brightness };
	Write(command, sizeof(command));
}

void SetRemember(uint8_t setting)
{
	uint8_t command[] = { 254, 147, setting };
	Write(command, sizeof(command));
}

void SetDataLock(uint8_t level)
{
	uint8_t command[] = { 254, 202, 245, 160, level };
	Write(command, sizeof(command));
}

void SetandSaveDataLock(uint8_t level)
{
	uint8_t command[] = { 254, 203, 245, 160, level };
	Write(command, sizeof(command));
}

void WriteCustomerData(uint8_t data[], size_t length)
{
	uint8_t command[] = { 254, 52 };
	Write(command, sizeof(command));
	Write(data, length);
}

uint32_t ReadCustomerData(uint8_t data[], size_t length)
{
	uint8_t command[] = { 254, 53 };
	Write(command, sizeof(command));
	return (Read(data, length));
}

uint32_t ReadVersionNumber(uint8_t data[], size_t length)
{
	uint8_t command[] = { 254, 54 };
	Write(command, sizeof(command));
	return (Read(data, length));
}

uint32_t ReadModuleType(uint8_t data[], size_t length)
{
	uint8_t command[] = { 254, 55 };
	Write(command, sizeof(command));
	return (Read(data, length));
}