#ifndef LK_KEY_DEMO_H
#define LK_KEY_DEMO_H
#include <stdint.h>
void MenuLoop(void);
void updateMenu(int8_t value);
void DrawMenu(void);
void drawMenuCursor(uint8_t last, uint8_t present);
void gotoSubMenu(uint8_t selection);
void updateBacklight(void);
void drawBacklightMenu(void);
void valueconverter(int16_t value);
void changeBrightness(int8_t change);
void updateContrast(void);
void drawContrastMenu(void);
void changeContrast(int8_t change);
void updateLedState(void);
void drawLedMenu7T(void);
void selectLED(int8_t led);
void changeLEDcolour(int8_t state);
void drawLedMenu4T(void);
void setdefaults(void);
#endif
