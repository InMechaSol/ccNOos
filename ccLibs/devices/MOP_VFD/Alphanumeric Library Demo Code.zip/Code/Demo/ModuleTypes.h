#define LK162_12_7T 50
#define LK162_12_4T 60
#define LK162_12_4T_USB 62
#define LK162_12_7T_USB 63