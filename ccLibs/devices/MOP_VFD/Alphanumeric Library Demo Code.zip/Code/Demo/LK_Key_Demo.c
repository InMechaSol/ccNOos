//Martino DeLeon, Matrix Orbital 2014
//www.matrixorbital.ca
//support@matrixorbital.ca

//Common Libraries
#include "AlphaDriver.h"
#include "AlphaInterface.h"
#include "ModuleTypes.h" 
#include "LK_Key_Demo.h"
#include <stdio.h> 
#include <string.h>
#ifdef __GNUC__	
//Linux Libraries
#include <termios.h>
#include <unistd.h> 
#include <fcntl.h> 
#include <sys/signal.h> 
#include <sys/types.h> 
#define sprintf_s snprintf
#define PORTNAME "/dev/ttyUSB0"
#else	
//Windows Libraries	
#include <windows.h>
#include <conio.h>
#include <stdint.h>
#define PORTNAME "\\\\.\\COM3"
#endif

//Global Variables
uint8_t Module[] = { 0 };
uint8_t current_selection = 1;
uint8_t previous_selection = 4;
uint8_t current_cursor = 1;
uint8_t previous_cursor = 2;
uint8_t key_press[] = { 0 };
int16_t contrast = 128;
int16_t brightness = 255;
int8_t selected_led = 0;
int8_t led_state = 3;
char* LED[3] = { "1", "2", "3" };
char* LEDColour[4] = { "OFF", "GRN", "RED", "YEL" };
int8_t LEDIND[3] = { 3, 3, 3 };

//Main Code
int main(int argc, char ** argv)
{
	uint32_t error = 0;
	fprintf(stderr, "C Language LK Driver Test\n");
	error = CreateInterface(PORTNAME);
	if (error != 0)
	{
		fprintf(stderr, "Error opening port!\n");
		return 1;
	}
	error = SetInterfaceParameters(19200);
	if (error != 0)
	{
		fprintf(stderr, "Error setting port parameters!\n");
		return 1;
	}
	error = SetInterfaceTimeouts(100);
	if (error != 0)
	{
		fprintf(stderr, "Error setting port timeouts!\n");
		return 1;
	}
	fprintf(stderr, "Reading Module...\n");
	WriteString("Reading...");
	ReadModuleType(Module, 1);
	fprintf(stderr, "Module is: %s \n", Module);
	switch (Module[0])
	{
		case 50:
			fprintf(stderr, "LK162-12-7T-1U is connected\n");
			break;
		case 63:
			fprintf(stderr, "LK162-12-7T--1U-USB is connected\n");
			break;
		case 60:
			fprintf(stderr, "LK162-12-4T-1U is connected\n");
			break;
		case 62:
			fprintf(stderr, "LK162-12-4T-1U-USB is connected\n");
			break;
		default:
			fprintf(stderr, "Error reading module. Please connect and try again.\n");
			return 1;
	}
		
	fprintf(stderr, "Running Demo...\n");
	fprintf(stderr, "Break to Exit.\n");
	AutoScrollOff();
	SetAutoLineWrapOn();
	AutoTransmitKeyPressesOff();
	ClearKeyBuffer();
	DrawMenu();
	drawMenuCursor(previous_cursor, current_cursor);
	AutoTransmitKeyPressesOff();
	
	do
	{
		MenuLoop();
	}
	while (1);
	DestroyInterface();
	return 0;
}

void MenuLoop(void)
{
	if (Module[0] == LK162_12_7T || Module[0] == LK162_12_7T_USB)
	{
		PollKeyPress(key_press, 1);
		switch (key_press[0])
		{
		case 'B': //Up
			updateMenu(-1);
			key_press[0] = 0;
			break;
		case 'H': //Down
			updateMenu(1);
			key_press[0] = 0;
			break;
		case 'E':  //Centre
			gotoSubMenu(current_selection);
			DrawMenu();
			updateMenu(0);
			key_press[0] = 0;
			break;
		default:
			key_press[0] = 0;
			break;
		}
	}
	else if (Module[0] == LK162_12_4T || Module[0] == LK162_12_4T_USB)
	{
		PollKeyPress(key_press, 1);
		switch (key_press[0])
		{
		case 'A': //Up
			updateMenu(-1);
			key_press[0] = 0;
			break;
		case 'C': //Down
			updateMenu(1);
			key_press[0] = 0;
			break;
		case 'D':  //Bottom Right
			gotoSubMenu(current_selection);
			DrawMenu();
			updateMenu(0);
			key_press[0] = 0;
			break;
		default:
			key_press[0] = 0;
			break;
		}
	}
}

void updateMenu(int8_t value)
{
	previous_selection = current_selection;
	current_selection += value;
	previous_cursor = current_cursor;
	current_cursor += value;
	if (current_selection > 4)
	{
		current_selection = 1;
		current_cursor = 1;
		DrawMenu();
	}
	if (current_selection == 2)
	{
		DrawMenu();
		current_cursor = 2;
	}
	if (current_selection <= 3)
	{
		DrawMenu();
		current_cursor = 1;
	}
	if (current_selection <= 4)
	{
		DrawMenu();
		current_cursor = 1;
	}
	if (current_selection < 1)
	{
		current_selection = 4;
		DrawMenu();
		current_cursor = 1;
	}
	drawMenuCursor(previous_cursor, current_cursor);
}

void DrawMenu(void)
{
	char* menu_strings[] = { "Backlight", "Contrast", "LED Indicators", "Defaults" };
	ClearScreen();
	uint8_t x = 1;
	if (current_selection == 1)
	{
		for (int i = 0; i < 2; i++)
		{
			SetCursorPosition(2, x);
			WriteString(menu_strings[i]);
			x++;
		}
	}
	if (current_selection == 2)
	{
		for (int i = 1; i < 3; i++)
		{
			SetCursorPosition(2, x);
			WriteString(menu_strings[i]);
			x++;
		}
	}
	if (current_selection == 3)
	{
		for (int i = 2; i < 4; i++)
		{
			SetCursorPosition(2, x);
			WriteString(menu_strings[i]);
			x++;
		}
	}
	if (current_selection == 4)
	{
		SetCursorPosition(2, 1);
		WriteString(menu_strings[3]);
		SetCursorPosition(2, 2);
		WriteString(menu_strings[0]);
	}
}

void drawMenuCursor(uint8_t last, uint8_t present)
{
	char blank[] = { " " };
	char arrow[] = { ">" };
	SetCursorPosition(1, last);
	WriteString(blank);
	SetCursorPosition(1, present);
	WriteString(arrow);
}

void gotoSubMenu(uint8_t selection)
{
	switch (selection)
	{
	case 1:
		updateBacklight();
		break;
	case 2:
		updateContrast();
		break;
	case 3:
		updateLedState();
		break;
	case 4:
		setdefaults();
		break;
	}
}

void updateBacklight(void)//Backlight menu loop
{
	char* quit = "no";
	drawBacklightMenu();
	while (strcmp(quit, "yes"))
		if (Module[0] == LK162_12_7T || Module[0] == LK162_12_7T_USB)
		{
		PollKeyPress(key_press, 1);
		switch (key_press[0])
		{
		case 'B':  //Up
			changeBrightness(15);
			key_press[0] = 0;
			break;
		case 'H':  //Down
			changeBrightness(-15);
			key_press[0] = 0;
			break;
		case 'E':  //Centre
			quit = "yes";
			key_press[0] = 0;
			break;
		}
		}
		else if (Module[0] == LK162_12_4T || Module[0] == LK162_12_4T_USB)
		{
			PollKeyPress(key_press, 1);
			switch (key_press[0])
			{
			case 'A':  //Up
				changeBrightness(20);
				key_press[0] = 0;
				break;
			case 'C':  //Down
				changeBrightness(-20);
				key_press[0] = 0;
				break;
			case 'B':  //Top Right
				quit = "yes";
				key_press[0] = 0;
				break;
			}
		}
}

void drawBacklightMenu(void)
{
	uint8_t x = 1;
	char* menu_strings[] = { "Backlight", "Value    �     �" };
	ClearScreen();
	for (int i = 0; i < 2; i++)
	{
		SetCursorPosition(1, x);
		WriteString(menu_strings[i]);
		x++;
	}
	valueconverter(brightness);	
}

void valueconverter(int16_t value)
{
	if (value == 255)
	{
		SetCursorPosition(10, 2);
		WriteString("-");

	}
	else if (value == 0)
	{
		SetCursorPosition(16, 2);
		WriteString("-");

	}
	else
	{
		SetCursorPosition(10, 2);
		WriteString("�     �");
	}
	SetCursorPosition(12, 2);
	char clear[] = { "   " };
	WriteString(clear);
	SetCursorPosition(12, 2);
	char buffer[20];
	sprintf_s(buffer, 5, "%u", value);
	WriteString(buffer);
}

void changeBrightness(int8_t change)
{
	brightness += change;
	if (brightness > 255)
	{
		brightness = 255;
	}
	if (brightness < 0)
	{
		brightness = 0;
	}
	SetBrightness((uint8_t)brightness);
	valueconverter((uint8_t)brightness);
}

void updateContrast(void)//Contrast menu loop
{
	char* quit = "no";
	drawContrastMenu();
	while (strcmp(quit, "yes"))
		if (Module[0] == LK162_12_7T || Module[0] == LK162_12_7T_USB)
		{
		PollKeyPress(key_press, 1);
		switch (key_press[0])
		{
		case 'B':  //Up
			changeContrast(16);
			key_press[0] = 0;
			break;
		case 'H':  //Down
			changeContrast(-16);
			key_press[0] = 0;
			break;
		case 'E':  //centre
			quit = "yes";
			key_press[0] = 0;
			break;
		}
		}
		else if (Module[0] == LK162_12_4T || Module[0] == LK162_12_4T_USB)
		{
			PollKeyPress(key_press, 1);
			switch (key_press[0])
			{
			case 'A':  //Up
				changeContrast(16);
				key_press[0] = 0;
				break;
			case 'C':  //Down
				changeContrast(-16);
				key_press[0] = 0;
				break;
			case 'B':  //Top Right
				quit = "yes";
				key_press[0] = 0;
				break;
			}
		}
}

void drawContrastMenu(void)
{
	uint8_t x = 1;
	char* menu_strings[] = { "Contrast", "Value    �     �" };
	ClearScreen();
	for (int i = 0; i < 2; i++)
	{
		SetCursorPosition(1, x);
		WriteString(menu_strings[i]);
		x++;
	}
	valueconverter(contrast);
}

void changeContrast(int8_t change)
{
	contrast += change;
	if (contrast > 255)
	{
		contrast = 255;
	}
	if (contrast < 0)
	{
		contrast = 0;
	}
	SetContrast((uint8_t)contrast);
	valueconverter((uint8_t)contrast);
}

void updateLedState(void)//LED menu loop
{
	char* quit = "no";
	if (Module[0] == LK162_12_7T || Module[0] == LK162_12_7T_USB)
	{
		drawLedMenu7T();
		while (strcmp(quit, "yes"))
		{
			PollKeyPress(key_press, 1);
			switch (key_press[0])
			{
			case 'B':  //up
				selectLED(-1);
				break;
			case 'H':  //down
				selectLED(1);
				break;
			case 'C':  //right
				changeLEDcolour(1);
				break;
			case 'D':  //left
				changeLEDcolour(-1);
				break;
			case 'E':  //centre
				quit = "yes";
				break;
			}
		}
	}
	else if (Module[0] == LK162_12_4T || Module[0] == LK162_12_4T_USB)
	{
		drawLedMenu4T();
		while (strcmp(quit, "yes"))
		{
			PollKeyPress(key_press, 1);
			switch (key_press[0])
			{
			case 'A':  //up
				selectLED(-1);
				break;
			case 'C':  //down
				selectLED(1);
				break;
			case 'D':  //Bottom Right
				changeLEDcolour(1);
				break;
			case 'B':  //Top Right
				quit = "yes";
				break;
			}
		}
	}

}

void drawLedMenu7T(void)
{
	uint8_t x = 1;
	char* menu_strings[] = { "LED      �     �", "Colour   �     �" };
	ClearScreen();
	for (int i = 0; i < 2; i++)
	{
		SetCursorPosition(1, x);
		WriteString(menu_strings[i]);
		x++;
	}
	SetCursorPosition(12, 2);
	WriteString(LEDColour[led_state]);
	SetCursorPosition(13, 1);
	WriteString(LED[selected_led]);
	if (selected_led == 2)
	{
		SetCursorPosition(16, 1);
		WriteString("-");
	}
	if (selected_led == 0)
	{
		SetCursorPosition(10, 1);
		WriteString("-");
	}
	if (led_state >= 3)
	{
		led_state = 3;
		SetCursorPosition(16, 2);
		WriteString("|");
	}
	if (led_state <= 0)
	{
		led_state = 0;
		SetCursorPosition(10, 2);
		WriteString("|");
	}
}

void selectLED(int8_t led)
{
	selected_led += led;
	if (selected_led >= 2)
	{
		selected_led = 2;
		SetCursorPosition(16, 1);
		WriteString("-");
	}
	if (selected_led <= 0)
	{
		selected_led = 0;
		SetCursorPosition(10, 1);
		WriteString("-");
	}
	else if (selected_led != 0 && selected_led != 2)
	{
		SetCursorPosition(10, 1);
		WriteString("�     �");
	}
	SetCursorPosition(13, 1);
	WriteString(LED[selected_led]);
	if (Module[0] == LK162_12_7T || Module[0] == LK162_12_7T_USB)
	{
		if (LEDIND[selected_led] > 3 || LEDIND[selected_led] == 3)
		{
			SetCursorPosition(10, 2);
			WriteString("�     |");
		}
		if (LEDIND[selected_led] < 0 || LEDIND[selected_led] == 0)
		{
			SetCursorPosition(10, 2);
			WriteString("|     �");
		}
		else if (LEDIND[selected_led] != 0 && LEDIND[selected_led] != 3)
		{
			SetCursorPosition(10, 2);
			WriteString("�     �");
		}
	}	
	SetCursorPosition(12, 2);
	WriteString(LEDColour[LEDIND[selected_led]]);
}

void changeLEDcolour(int8_t state)
{
	if (Module[0] == LK162_12_7T || Module[0] == LK162_12_7T_USB)
	{
		led_state = LEDIND[selected_led];
		led_state += state;
		if (led_state > 3 || led_state == 3)
		{
			led_state = 3;
			SetCursorPosition(16, 2);
			WriteString("|");
		}
		if (led_state < 0 || led_state == 0)
		{
			led_state = 0;
			SetCursorPosition(10, 2);
			WriteString("|");
		}
		else if (led_state != 0 && led_state != 3)
		{
			SetCursorPosition(10, 2);
			WriteString("�     �");
		}
	}
	else if (Module[0] == LK162_12_4T || Module[0] == LK162_12_4T_USB)
	{
		led_state += state;
		if (led_state > 3)
		{
			led_state = 0;
		}
		if (led_state < 0)
		{
			led_state = 3;
		}
	}

	SetLEDIndicators(selected_led, led_state);
	SetCursorPosition(12, 2);
	WriteString(LEDColour[led_state]);
	LEDIND[selected_led] = led_state;
}

void drawLedMenu4T(void)
{
	uint8_t x = 1;
	char* menu_strings[] = { "LED      �     �", "Colour" };
	ClearScreen();
	for (int i = 0; i < 2; i++)
	{
		SetCursorPosition(1, x);
		WriteString(menu_strings[i]);
		x++;
	}
	SetCursorPosition(12, 2);
	WriteString(LEDColour[led_state]);
	SetCursorPosition(13, 1);
	WriteString(LED[selected_led]);
	if (selected_led == 2)
	{
		SetCursorPosition(16, 1);
		WriteString("-");
	}
	else if (selected_led == 0)
	{
		SetCursorPosition(10, 1);
		WriteString("-");
	}
}

void setdefaults(void)
{
	SetContrast(128);
	contrast = 128;
	SetBrightness(255);
	brightness = 255;
	SetLEDIndicators(0, 3);
	SetLEDIndicators(1, 3);
	SetLEDIndicators(2, 3);
	selected_led = 0;
	led_state = 3;
	LEDIND[0] = 3;
	LEDIND[1] = 3;
	LEDIND[2] = 3;
}
