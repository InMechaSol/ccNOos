Project files for the AlphaLibrary Demo can be compiled using CMake.


Install CMake:
Download latest version from http://www.cmake.org/


Run CMake:
To run CMake, open a terminal and navigate to the "Build" folder
From within the "Build" folder, type "cmake .."


Build Windows Project:
Build AlphaDemo.sln
Navigate to "Ouptput/Debug/Demo.exe" to run the demo


Build Linux Project:
Within the "Build" folder, type "make"
Navigate to "Output" and type "./Demo"



Matrix Orbital
support@matrixorbital.ca
